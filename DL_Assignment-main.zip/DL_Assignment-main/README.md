# Early stopping

# ESBM - EarlyStopping customized to your own needs

Background
This package will be assiting easily you with several training phases:

First, you should define your required metric.

ESBM will then evaulate your model performance on the validation set.

It will select the best classsification threshold and inform you about the results.

It will save the best evaualted model for future use.

It will initate early stopping after a defined period with no metric improvment.

